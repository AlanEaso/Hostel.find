from django.apps import AppConfig


class UserAccountsConfig(AppConfig):
    name = 'user_accounts'
